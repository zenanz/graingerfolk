$("#toFavorites").click(function() {
    window.location = "/accounts/favorites";
    console.log('click')
});